CSC 361 Programming assignment 2 Spring 2021
Name: Kenil Shah

How to run: 

Enter the following in the command line:

	python3 TCPtrafficAnalysis.py <pcap-filename>